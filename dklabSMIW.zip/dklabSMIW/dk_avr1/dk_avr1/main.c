/*
 * dk_avr1.c
 *
 * Created: 26.05.2025 12:41:56
 * Author : student
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

